

<?php $__env->startSection('title', $menu->title); ?>

<?php $__env->startSection('styles'); ?>
    
    <link href="<?php echo e(asset('/extra-libs/prism/prism.css')); ?>" rel="stylesheet">
    
    
    <link href="<?php echo e(asset('/libs/select2/dist/css/select2.css')); ?>" rel="stylesheet">
    
    
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/libs/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col s12">
                <div class="card">
                    <div class="card-content">
                        <h5 class="card-title">Tambah <?php echo e($menu->title); ?></h5>
                        <?php if(session('status')): ?>
                            <div class="success-alert-bar p-15 m-t-10 m-b-10 red white-text" style="display: block">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <form method="POST" action="<?php echo e(str_replace("/create", "", $menu->url)); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="input-field col s6">
                                    <input id="title" type="text" placeholder="Jadwal UTS" name="title" value="<?php echo e(old('title')); ?>">
                                    <label for="title">Judul <span class="materialize-red-text">*</span></label>
                                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-field col s3">
                                    <select id="category" name="category" class="">
                                        <option value="" selected>--- SILAHKAN PILIH ---</option>
                                        <?php if($categories): ?>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php if(old('category') == $category->id): ?> selected <?php endif; ?> value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                    <label for="category">Kategori <span class="materialize-red-text">*</span></label>
                                    <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-field col s3">
                                    <select id="tag" name="tag" class="">
                                        <option value="" selected>--- SILAHKAN PILIH ---</option>
                                        <?php if($tags): ?>
                                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php if(old('tag') == $tag->id): ?> selected <?php endif; ?> value="<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                    <label for="tag">Tag</label>
                                    <?php $__errorArgs = ['tag'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-field col s12">
                                    <p>Deskripsi <span class="materialize-red-text">*</span></p>
                                    <textarea id="mymce" name="description"><?php echo e(old('description')); ?></textarea>
                                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="file-field input-field col s12">
                                    <div class="btn">
                                        <span>Unggah Foto</span>
                                        <input type="file" name="photo" id="photo" value="<?php echo e(old('photo')); ?>">
                                    </div>
                                    <div class="file-path-wrapper">
                                        <input class="file-path validate" type="text">
                                    </div>
                                    <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-field col s6">
                                    <select id="status" name="status" class="">
                                        <option <?php if(old('status') == 'new'): ?> selected <?php endif; ?> value="<?php echo e('new'); ?>" selected>Baru</option>
                                        <option <?php if(old('status') == 'publish'): ?> selected <?php endif; ?> value="<?php echo e('publish'); ?>">Terbit</option>
                                        <option <?php if(old('status') == 'draft'): ?> selected <?php endif; ?> value="<?php echo e('draft'); ?>">Arsip</option>
                                    </select>
                                    <label for="status">Status</label>
                                    <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-field col s6">
                                    <input id="author" type="text" placeholder="Safira" name="author" value="<?php echo e(old('author')); ?>">
                                    <label for="author">Penulis <span class="materialize-red-text">*</span></label>
                                    <?php $__errorArgs = ['author'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <hr>
                            <div class="row">
                                <div class="col s12" style="text-align: right">
                                    <a class="waves-effect waves-light btn btn-round blue strong" href="<?php echo e($menu->url); ?>">KEMBALI</a>
                                    <button class="waves-effect waves-light btn btn-round green strong" type="submit">SIMPAN</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
    <script src="<?php echo e(asset('/extra-libs/prism/prism.js')); ?>"></script>
    
    
    <script src="<?php echo e(asset('/libs/select2/dist/js/select2.min.js')); ?>"></script>

    
    <script src="<?php echo e(asset('/libs/moment/moment.js')); ?>"></script>
    <script src="<?php echo e(asset('/libs/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker-custom.js')); ?>"></script>
    
    
    <script src="<?php echo e(asset('/libs/tinymce/tinymce.min.js')); ?>"></script>
    
    
    <script src="<?php echo e(asset('/dist/js/form.js')); ?>"></script>
    <?php echo $__env->make('scripts.tinymce', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('scripts.datepicker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('scripts.select2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\Laravel\siakad_fira\resources\views/studies/article/create.blade.php ENDPATH**/ ?>