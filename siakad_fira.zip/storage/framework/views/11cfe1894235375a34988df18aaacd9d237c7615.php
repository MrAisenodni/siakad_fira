

<?php $__env->startSection('title', $menu->title); ?>

<?php $__env->startSection('styles'); ?>
    
    <link href="<?php echo e(asset('/dist/css/pages/data-table.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col s12">
                <div class="card">
                    <div class="card-content">
                        <div class="row">
                            <div class="col s10">
                                <h5 class="card-title">Daftar <?php echo e($menu->title); ?></h5>
                            </div>
                        </div>
                        <table id="zero_config" class="responsive-table display" style="width:100%" onload="message()">
                            <thead>
                                <tr>
                                    <th>Judul</th>
                                    <th>Kategori</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($articles): ?>
                                    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="show" data-id="<?php echo e($article->id); ?>">
                                            <td><?php echo e($article->title); ?></td>
                                            <td><?php echo e($article->category->name); ?></td>
                                            <td>
                                                <?php if($article->status == 'new'): ?>
                                                    <button class="waves-effect waves-light btn btn-round primary strong" type="button">BARU</button>
                                                <?php elseif($article->status == 'publish'): ?>
                                                    <button class="waves-effect waves-light btn btn-round green strong" type="button">TERBIT</button>
                                                <?php else: ?>
                                                    <button class="waves-effect waves-light btn btn-round red strong" type="button">ARSIP</button>
                                                <?php endif; ?> 
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
    <script src="<?php echo e(asset('/extra-libs/Datatables/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/dist/js/pages/datatable/datatable-basic.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\Laravel\siakad_fira\resources\views/teachers/article/index.blade.php ENDPATH**/ ?>