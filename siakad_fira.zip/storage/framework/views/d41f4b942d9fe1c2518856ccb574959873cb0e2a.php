

<?php $__env->startSection('title', $menu->title); ?>

<?php $__env->startSection('styles'); ?>
    
    <link href="<?php echo e(asset('/extra-libs/prism/prism.css')); ?>" rel="stylesheet">
    
    
    <link href="<?php echo e(asset('/libs/select2/dist/css/select2.css')); ?>" rel="stylesheet">

    
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/libs/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col s12">
                <div class="card">
                    <div class="card-content">
                        <h5 class="card-title">Tambah <?php echo e($menu->title); ?></h5>
                        <form method="POST" action="<?php echo e(str_replace("/create", "", $menu->url)); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="input-field col s2">
                                    <select id="type" name="type" class="">
                                        <option <?php $__errorArgs = [old('type') == 'std'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> selected <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> value="std" selected>UMUM</option>
                                        <option <?php $__errorArgs = [old('type') == 'uts'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> selected <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> value="uts">UTS</option>
                                        <option <?php $__errorArgs = [old('type') == 'uas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> selected <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> value="uas">UAS</option>
                                    </select>
                                    <label for="type">Tipe</label>
                                    <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-field col s10">
                                    <select id="lesson" name="lesson" class="">
                                        <option value="" selected>--- SILAHKAN PILIH ---</option>
                                        <?php if($lessons): ?>
                                            <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php if(old('lesson') == $lesson->id): ?> selected <?php endif; ?> value="<?php echo e($lesson->id); ?>">[<?php echo e($lesson->teacher->nip); ?>] <?php echo e($lesson->teacher->full_name); ?> | <?php echo e($lesson->lesson->name); ?> (<?php echo e($lesson->class->name); ?>)</option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                    <label for="lesson">Mata Pelajaran <span class="materialize-red-text">*</span></label>
                                    <?php $__errorArgs = ['lesson'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row">
                                <div class="input-field col s3">
                                    <select id="day" name="day" class="">
                                        <option <?php if(old('day') == '1'): ?> selected <?php endif; ?> value="1" selected>Senin</option>
                                        <option <?php if(old('day') == '2'): ?> selected <?php endif; ?> value="2">Selasa</option>
                                        <option <?php if(old('day') == '3'): ?> selected <?php endif; ?> value="3">Rabu</option>
                                        <option <?php if(old('day') == '4'): ?> selected <?php endif; ?> value="4">Kamis</option>
                                        <option <?php if(old('day') == '5'): ?> selected <?php endif; ?> value="5">Jumat</option>
                                        <option <?php if(old('day') == '6'): ?> selected <?php endif; ?> value="6">Sabtu</option>
                                        <option <?php if(old('day') == '7'): ?> selected <?php endif; ?> value="7">Minggu</option>
                                    </select>
                                    <label for="day">Hari <span class="materialize-red-text">*</span></label>
                                    <?php $__errorArgs = ['day'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col s2">
                                    <label for="clock_in" class="m-t-20">Masuk <span class="materialize-red-text">*</span></label>
                                    <div class="input-fleid">
                                        <input id="clock_in" type="text" name="clock_in" placeholder="07:00" class="timepicker" value="<?php echo e(old('clock_in')); ?>">
                                    </div>
                                    <?php $__errorArgs = ['clock_in'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col s2">
                                    <label for="clock_out" class="m-t-20">Keluar <span class="materialize-red-text">*</span></label>
                                    <div class="input-fleid">
                                        <input id="clock_out" type="text" name="clock_out" placeholder="09:00" class="timepicker" value="<?php echo e(old('clock_out')); ?>">
                                    </div>
                                    <?php $__errorArgs = ['clock_out'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-field col s5">
                                    <select id="spv_teacher" name="spv_teacher" class="" disabled>
                                        <option value="" selected>--- SILAHKAN PILIH ---</option>
                                        <?php if($teachers): ?>
                                            <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php if(old('spv_teacher') == $teacher->id): ?> selected <?php endif; ?> value="<?php echo e($teacher->id); ?>">[<?php echo e($teacher->nip); ?>] <?php echo e($teacher->full_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                    <label for="spv_teacher">Guru Pengawas</label>
                                    <?php $__errorArgs = ['spv_teacher'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <p class="error">*Jika Tipe diisi bernilai UTS atau UAS, maka Guru Pengawas wajib diisi.</p>

                            <hr>
                            <div class="row">
                                <div class="col s12" style="text-align: right">
                                    <a class="waves-effect waves-light btn btn-round blue strong" href="<?php echo e($menu->url); ?>">KEMBALI</a>
                                    <button class="waves-effect waves-light btn btn-round green strong" type="submit">SIMPAN</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
    <script src="<?php echo e(asset('/extra-libs/prism/prism.js')); ?>"></script>
    
    
    <script src="<?php echo e(asset('/libs/select2/dist/js/select2.min.js')); ?>"></script>

    
    <script src="<?php echo e(asset('/libs/moment/moment.js')); ?>"></script>
    <script src="<?php echo e(asset('/libs/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker-custom.js')); ?>"></script>

    
    <script src="<?php echo e(asset('/dist/js/form.js')); ?>"></script>
    <?php echo $__env->make('scripts.datepicker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('scripts.select2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\Laravel\siakad_fira\resources\views/studies/schedule/create.blade.php ENDPATH**/ ?>