

<?php $__env->startSection('title', $menu->title); ?>

<?php $__env->startSection('styles'); ?>
    
    <link href="<?php echo e(asset('/dist/css/pages/data-table.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col s12">
                <div class="card">
                    <div class="card-content">
                        <h5 class="card-title">Detail Siswa</h5>
                        <div class="row">
                            <div class="col s12"><hr>
                                <div class="row">
                                    <div class="input-field col s2">
                                        <input id="nis" type="text" name="nis" value="<?php echo e($student->nis); ?>" disabled>
                                        <label for="nis">NIS</label>
                                    </div>
                                    <div class="input-field col s2">
                                        <input id="nisn" type="text" name="nisn" value="<?php echo e($student->nisn); ?>" disabled>
                                        <label for="nisn">NISN</label>
                                        <?php $__errorArgs = ['nisn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="error"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="input-field col s7">
                                        <input id="full_name" type="text" name="full_name" value="<?php echo e($student->full_name); ?>" disabled>
                                        <label for="full_name">Nama Lengkap</label>
                                    </div>
                                    <div class="input-field col s1">
                                        <input id="clazz" type="text" name="clazz" value="<?php echo e($student->class->class->name); ?>" disabled>
                                        <label for="clazz">Kelas</label>
                                        <?php $__errorArgs = ['clazz'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="error"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col s12" style="text-align: right">
                                        <a class="waves-effect waves-light btn btn-round blue strong" href="<?php echo e(url()->previous()); ?>">KEMBALI</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <div class="card-content">
                        <div class="row">
                            <div class="col s10">
                                <h5 class="card-title"><?php echo e($menu->title); ?></h5>
                            </div>
                            <div class="col s2 right-align">
                                <a class="waves-effect waves-light btn btn-round green strong" href="<?php echo e(url()->current()); ?>/create">TAMBAH</a>
                            </div>
                            <?php if(session('status')): ?>
                                <div class="col s12">
                                    <div class="success-alert-bar p-15 m-t-10 green white-text" style="display: block">
                                        <?php echo e(session('status')); ?>

                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="row">
                            <div class="col s12">
                                <table id="zero_config" class="responsive-table display" style="width:100%" onload="message()">
                                    <thead>
                                        <tr>
                                            <th>Mata Pelajaran</th>
                                            <th>Bulan 1</th>
                                            <th>Bulan 2</th>
                                            <th>Bulan 3</th>
                                            <th>Bulan 4</th>
                                            <th>UTS</th>
                                            <th>UAS</th>
                                            <th>Nilai Akhir</th>
                                            <th>Nilai Rata-Rata</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if($reports): ?>
                                            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr id="data" data-id="<?php echo e($report->id); ?>" data-aid="<?php echo e($student->id); ?>">
                                                    <td><?php echo e($report->lesson->name); ?></td>
                                                    <td><?php echo e($report->score_1); ?></td>
                                                    <td><?php echo e($report->score_2); ?></td>
                                                    <td><?php echo e($report->score_3); ?></td>
                                                    <td><?php echo e($report->score_4); ?></td>
                                                    <td><?php echo e($report->score_uts); ?></td>
                                                    <td><?php echo e($report->score_uas); ?></td>
                                                    <td><?php echo e($report->score_na); ?></td>
                                                    <td><?php echo e($report->score_avg); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="row m-t-10">
                            <div class="col s12" style="text-align: right">
                                <a class="waves-effect waves-light btn btn-round blue strong" href="<?php echo e(url()->previous()); ?>">KEMBALI</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
    <script src="<?php echo e(asset('/extra-libs/Datatables/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/dist/js/pages/datatable/datatable-basic.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\Laravel\siakad_fira\resources\views/studies/report/show.blade.php ENDPATH**/ ?>