

<?php $__env->startSection('title', $menu->title); ?>

<?php $__env->startSection('styles'); ?>
    
    <link href="<?php echo e(asset('/extra-libs/prism/prism.css')); ?>" rel="stylesheet">

    
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/libs/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col s12">
                <div class="card">
                    <div class="card-content">
                        <h5 class="card-title"><?php echo e($menu->title); ?> Siswa</h5>
                        <form method="POST" action="<?php echo e($menu->url); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="clazz_id" value="<?php echo e($clazz->id); ?>">
                            <div class="row">
                                <div class="input-field col s5">
                                    <input id="study_date" class="datepicker" type="text" placeholder="dd/mm/yyyy" name="study_date" value="<?php echo e(old('study_date', $study_date)); ?>" required>
                                    <label for="study_date">Tanggal</label>
                                    <?php $__errorArgs = ['study_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-field col s3">
                                    <label for="clazz">Kelas</label>
                                    <input id="clazz" type="text" name="clazz" value="<?php echo e($clazz->class->name); ?>" disabled>
                                </div>
                                <div class="input-field col s4">
                                    <label for="study_year">Tahun Pelajaran</label>
                                    <input id="study_year" type="text" name="study_year" value="<?php echo e($clazz->study_year->name); ?>" disabled>
                                </div>
                            </div>

                            <hr>
                            <div class="row">
                                <div class="col s12" style="text-align: right">
                                    <a class="waves-effect waves-light btn btn-round blue strong" href="<?php echo e($menu->url); ?>">KEMBALI</a>
                                    <button class="waves-effect waves-light btn btn-round green strong" type="submit">TAMBAH</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card">
                    <div class="card-content">
                        <form method="POST" action="<?php echo e(url()->current()); ?>/<?php echo e($clazz->id); ?>">
                            <?php echo method_field('put'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col s8">
                                    <h5 class="card-title">Daftar Siswa</h5>
                                </div>
                                <div class="col s4" style="text-align: right">
                                    <button class="waves-effect waves-light btn btn-round green strong" type="submit">SIMPAN</button>
                                </div>
                            </div>
                            <?php if(session('status')): ?>
                                <div class="row">
                                    <div class="col s12">
                                        <div class="success-alert-bar p-15 m-t-10 green white-text" style="display: block">
                                            <?php echo e(session('status')); ?>

                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php if(session('error')): ?>
                                <div class="row">
                                    <div class="col s12">
                                        <div class="success-alert-bar p-15 m-t-10 red white-text" style="display: block">
                                            <?php echo e(session('error')); ?>

                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?><hr>
                            <input type="hidden" name="study_date" value="<?php echo e(old('study_date', $study_date)); ?>">
                            <input type="hidden" name="c_student" value="<?php echo e($classes->count()); ?>">
                            <?php if($classes): ?>
                                <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $claz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row">
                                        <div class="input-field col s8">
                                            <label for="full_name">Nama Siswa</label>
                                            <input id="full_name" type="text" name="full_name" value="<?php echo e($claz->student->full_name); ?>" disabled>
                                        </div>
                                        <div class="col s1">
                                            <label class="input-field">
                                                <input class="with-gap" name="present<?php echo e($loop->iteration); ?>" type="radio" value="present" checked />
                                                <span>Hadir</span>
                                            </label>
                                        </div>
                                        <div class="col s1">
                                            <label class="input-field">
                                                <input class="with-gap" name="present<?php echo e($loop->iteration); ?>" type="radio" value="sick" />
                                                <span>Sakit</span>
                                            </label>
                                        </div>
                                        <div class="col s1">
                                            <label class="input-field">
                                                <input class="with-gap" name="present<?php echo e($loop->iteration); ?>" type="radio" value="permit" />
                                                <span>Izin</span>
                                            </label>
                                        </div>
                                        <div class="col s1">
                                            <label class="input-field">
                                                <input class="with-gap" name="present<?php echo e($loop->iteration); ?>" type="radio" value="absent" />
                                                <span>Absen</span>
                                            </label>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>

                            <hr>
                            <div class="row">
                                <div class="col s12" style="text-align: right">
                                    <button class="waves-effect waves-light btn btn-round green strong" type="submit">SIMPAN</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
    <script src="<?php echo e(asset('/extra-libs/prism/prism.js')); ?>"></script>

    
    <script src="<?php echo e(asset('/libs/moment/moment.js')); ?>"></script>
    <script src="<?php echo e(asset('/libs/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker-custom.js')); ?>"></script>

    
    <script src="<?php echo e(asset('/dist/js/form.js')); ?>"></script>
    <?php echo $__env->make('scripts.datepicker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\Laravel\siakad_fira\resources\views/teachers/present/create.blade.php ENDPATH**/ ?>