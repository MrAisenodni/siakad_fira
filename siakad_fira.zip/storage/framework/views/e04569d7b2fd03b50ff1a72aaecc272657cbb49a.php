

<?php $__env->startSection('title', $menu->title); ?>

<?php $__env->startSection('styles'); ?>
    
    <link href="<?php echo e(asset('/extra-libs/prism/prism.css')); ?>" rel="stylesheet">
    
    
    <link href="<?php echo e(asset('/libs/select2/dist/css/select2.css')); ?>" rel="stylesheet">

    
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/libs/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col s12">
                <div class="card">
                    <div class="card-content">
                        <h5 class="card-title"><?php echo e($menu->title); ?> Siswa</h5>
                        <form method="POST" action="<?php echo e(str_replace("/create", "", $menu->url)); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="clazz_id" value="<?php echo e($present->class_id); ?>">
                            <input type="hidden" name="study_year_id" value="<?php echo e($present->study_year_id); ?>">
                            <div class="row">
                                <div class="input-field col s4">
                                    <select id="month" name="month" class="">
                                        <option value="" selected>--- SILAHKAN PILIH ---</option>
                                        <?php if($months): ?>
                                            <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php if(old('month') == $month->id): ?> selected <?php endif; ?> value="<?php echo e($month->id); ?>"><?php echo e($month->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                    <label for="month">Bulan <span class="materialize-red-text">*</span></label>
                                    <?php $__errorArgs = ['month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-field col s4">
                                    <label for="clazz">Kelas</label>
                                    <input id="clazz" type="text" name="clazz" value="<?php echo e($present->class->name); ?>" disabled>
                                </div>
                                <div class="input-field col s4">
                                    <label for="study_year">Tahun Pelajaran</label>
                                    <input id="study_year" type="text" name="study_year" value="<?php echo e($present->study_year->name); ?>" disabled>
                                </div>
                            </div>

                            <hr>
                            <div class="row">
                                <div class="col s12" style="text-align: right">
                                    <a class="waves-effect waves-light btn btn-round blue strong" href="<?php echo e($menu->url); ?>">KEMBALI</a>
                                    <button class="waves-effect waves-light btn btn-round green strong" type="submit">SIMPAN</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <?php if($month): ?>
                    <div class="card">
                        <div class="card-content">
                            <div class="row">
                                <div class="col s12">
                                    <table id="zero_config" class="responsive-table display" style="width:100%" onload="message()">
                                        <thead>
                                            <tr>
                                                <th>Nama Siswa</th>
                                                <th>Hari</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <td>Muhammad Fiqri Alfayed</td>
                                            <td>1</td>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
    <script src="<?php echo e(asset('/extra-libs/prism/prism.js')); ?>"></script>
    
    
    <script src="<?php echo e(asset('/libs/select2/dist/js/select2.min.js')); ?>"></script>

    
    <script src="<?php echo e(asset('/libs/moment/moment.js')); ?>"></script>
    <script src="<?php echo e(asset('/libs/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker-custom.js')); ?>"></script>

    
    <script src="<?php echo e(asset('/dist/js/form.js')); ?>"></script>
    <?php echo $__env->make('scripts.datepicker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('scripts.select2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\Laravel\siakad_fira\resources\views/teachers/present/show.blade.php ENDPATH**/ ?>