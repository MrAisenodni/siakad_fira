

<?php $__env->startSection('title', $menu->title); ?>

<?php $__env->startSection('styles'); ?>
    <link href="<?php echo e(asset('/dist/css/pages/dashboard1.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <!-- ============================================================== -->
    <!-- Title and breadcrumb -->
    <!-- ============================================================== -->
    
    <!-- ============================================================== -->
    <!-- Container fluid scss in scafholding.scss -->
    <!-- ============================================================== -->
    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Sales Summery -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col l3 m6 s12">
                <div class="card danger-gradient card-hover">
                    <div class="card-content">
                        <div class="d-flex no-block align-items-center">
                            <div>
                                <h2 class="white-text m-b-5">250</h2>
                                <h6 class="white-text op-5 light-blue-text">Invoices</h6>
                            </div>
                            <div class="ml-auto">
                                <span class="white-text display-6"><i class="material-icons">assignment</i></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col l3 m6 s12">
                <div class="card info-gradient card-hover">
                    <div class="card-content">
                        <div class="d-flex no-block align-items-center">
                            <div>
                                <h2 class="white-text m-b-5">520</h2>
                                <h6 class="white-text op-5">News Feed</h6>
                            </div>
                            <div class="ml-auto">
                                <span class="white-text display-6"><i class="material-icons">receipt</i></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
             
            
            <div class="col l3 m6 s12">
                <div class="card success-gradient card-hover">
                    <div class="card-content">
                        <div class="d-flex no-block align-items-center">
                            <div>
                                <h2 class="white-text m-b-5">100</h2>
                                <h6 class="white-text op-5 text-darken-2">Sales</h6>
                            </div>
                            <div class="ml-auto">
                                <span class="white-text display-6"><i class="material-icons">equalizer</i></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           
            <div class="col l3 m6 s12">
                <div class="card warning-gradient card-hover">
                    <div class="card-content">
                        <div class="d-flex no-block align-items-center">
                            <div>
                                <h2 class="white-text m-b-5">450</h2>
                                <h6 class="white-text op-5">Revenue</h6>
                            </div>
                            <div class="ml-auto">
                                <span class="white-text display-6"><i class="material-icons">attach_money</i></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- Sales Summery -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col s12 l8">
                <div class="card">
                    <div class="card-content">
                        <div class="d-flex align-items-center">
                            <div>
                                <h5 class="card-title">Yearly Sales</h5>
                            </div>
                            <div class="ml-auto">
                                <ul class="list-inline font-12 dl m-r-10">
                                    <li class="cyan-text"><i class="fa fa-circle"></i> Earnings</li>
                                    <li class="blue-text text-accent-4"><i class="fa fa-circle"></i> Sales</li>
                                </ul>
                            </div>
                        </div>
                        <!-- Sales Summery -->
                        <div class="p-t-20">
                            <div class="row">
                                <div class="col s12">
                                    <div id="sales" style="height: 332px;"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col s12 l4">
                <div class="card card-hover">
                    <div class="card-content">
                        <div class="d-flex align-items-center">
                            <div class="m-r-20">
                                <h1 class=""><i class="ti-light-bulb"></i></h1></div>
                            <div>
                                <h3 class="card-title">Sales Analytics</h3>
                                <h6 class="card-subtitle">March  2017</h6> </div>
                        </div>
                        <div class="row d-flex align-items-center">
                            <div class="col s6">
                                <h3 class="font-light m-t-10"><sup><small><i class="ti-arrow-up"></i></small></sup>35487</h3>
                            </div>
                            <div class="col s6 right-align">
                                <div class="p-t-10 p-b-10">
                                    <div class="spark-count" style="height:65px"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card card-hover">
                    <div class="card-content">
                        <div class="d-flex align-items-center">
                            <div class="m-r-20">
                                <h1 class=""><i class="ti-pie-chart"></i></h1></div>
                            <div>
                                <h3 class="card-title">Bandwidth usage</h3>
                                <h6 class="card-subtitle">March  2017</h6> 
                            </div>
                        </div>
                        <div class="row d-flex align-items-center">
                            <div class="col s6">
                                <h3 class="font-light m-t-10">50 GB</h3>
                            </div>
                            <div class="col s6 p-t-10 p-b-20 right-align">
                                <div class="p-t-10 p-b-10 m-r-20">
                                    <div class="spark-count2" style="height:65px"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- Sales -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col s12 l4">
                <div class="card">
                    <div class="card-content">
                        <h5 class="card-title">Messages</h5>
                        <div class="message-box">
                            <div class="message-widget message-scroll">
                                <!-- Message -->
                                <a href="javascript:void(0)">
                                    <div class="user-img"> <img src="<?php echo e(asset('/images/users/d1.jpg')); ?>" alt="user" class="circle"> <span class="profile-status online pull-right"></span> </div>
                                    <div class="mail-contnet">
                                        <h5>Pavan kumar</h5> <span class="mail-desc">Lorem Ipsum is simply dummy text of the printing and type setting industry. Lorem Ipsum has been.</span> <span class="time">9:30 AM</span> </div>
                                </a>
                                <!-- Message -->
                                <a href="javascript:void(0)">
                                    <div class="user-img"> <img src="<?php echo e(asset('/images/users/d2.jpg')); ?>" alt="user" class="circle"> <span class="profile-status busy pull-right"></span> </div>
                                    <div class="mail-contnet">
                                        <h5>Sonu Nigam</h5> <span class="mail-desc">I've sung a song! See you at</span> <span class="time">9:10 AM</span> </div>
                                </a>
                                <!-- Message -->
                                <a href="javascript:void(0)">
                                    <div class="user-img"> <img src="<?php echo e(asset('/images/users/4.jpg')); ?>" alt="user" class="circle"> <span class="profile-status away pull-right"></span> </div>
                                    <div class="mail-contnet">
                                        <h5>Arijit Sinh</h5> <span class="mail-desc">Simply dummy text of the printing and typesetting industry.</span> <span class="time">9:08 AM</span> </div>
                                </a>
                                <!-- Message -->
                                <a href="javascript:void(0)">
                                    <div class="user-img"> <img src="<?php echo e(asset('/images/users/d4.jpg')); ?>" alt="user" class="circle"> <span class="profile-status offline pull-right"></span> </div>
                                    <div class="mail-contnet">
                                        <h5>Pavan kumar</h5> <span class="mail-desc">Just see the my admin!</span> <span class="time">9:02 AM</span> </div>
                                </a>
                                <!-- Message -->
                                <a href="javascript:void(0)">
                                    <div class="user-img"> <img src="<?php echo e(asset('/images/users/d5.jpg')); ?>" alt="user" class="circle"> <span class="profile-status online pull-right"></span> </div>
                                    <div class="mail-contnet">
                                        <h5>Pavan kumar</h5> <span class="mail-desc">Welcome to the Elite Admin</span> <span class="time">9:30 AM</span> </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col s12 l8">
                <div class="card news-slide" style="background:url(<?php echo e(asset('/images/carousel/img6.jpg')); ?>) center center / cover;">
                    <div class="carousel carousel-slider" >
                        <a class="carousel-item" href="#one!">
                            <div class="carousel-caption">
                                <span class="label label-danger label-rounded">News</span>
                                <h3 class="m-t-5 font-light white-text">Market Stock exchange status</h3>
                                <p class="white-text">It has survived not only five centuries, but also the leap into electronic typesetting</p>
                                <div class="row">
                                    <div class="col m4 m-t-10">
                                        <h4 class="m-b-0 green-text"><i class="ti-arrow-up"></i>350</h4><span class="white-text op-5">Reliance</span>
                                    </div>
                                    <div class="col m4 m-t-10">
                                        <h4 class="m-b-0 orange-text text-darken-2"><i class="ti-arrow-down"></i>-150</h4><span class="white-text op-5">Birla</span>
                                    </div>
                                    <div class="col m4 m-t-10">
                                        <h4 class="m-b-0 green-text"><i class="ti-arrow-up"></i>650</h4><span class="white-text op-5">Tata</span>
                                    </div>
                                </div>
                            </div>
                        </a>
                        <a class="carousel-item" href="#one!" style="background:url(<?php echo e(asset('/images/carousel/img6.jpg')); ?>) center center / cover;">
                            <div class="carousel-caption">
                                <span class="label label-danger label-rounded">Personal</span>
                                <p class="white-text m-t-10">It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
                            </div>
                        </a>
                        <a class="carousel-item" href="#one!" style="background:url(<?php echo e(asset('/images/carousel/img6.jpg')); ?>) center center / cover;">
                            <div class="carousel-caption">
                                <span class="label label-info label-rounded">Design</span>
                                <p class="white-text m-t-10">It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- product sales anf active users -->
        <!-- ============================================================== -->
        <div class="row">
            <div class="col s12">
                <div class="card">
                    <div class="card-content">
                        <div class="d-flex align-items-center">
                            <div>
                                <h5 class="card-title">Recent Sales</h5>
                                <h6 class="card-subtitle">Sales on products we have</h6>
                            </div>
                            <div class="ml-auto">
                                <div class="input-field dl support-select">
                                    <select>
                                        <option value="0" selected>10 Mar - 10 Apr</option>
                                        <option value="1">10 Apr - 10 May</option>
                                        <option value="2">10 May - 10 Jun</option>
                                        <option value="3">10 Jun - 10 Jul</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive m-b-20">
                            <table class="">
                                <thead>
                                    <tr>
                                        <th>Executives</th>
                                        <th>Product</th>
                                        <th>Price</th>
                                        <th>Date</th>
                                        <th>Status</th>
                                        <th>Progress</th>
                                        <th>Sales</th>
                                        <th>Earned</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>
                                            <div class="d-flex no-block align-items-center">
                                                <div class="m-r-10"><img src="<?php echo e(asset('/images/users/d1.jpg')); ?>" alt="user" class="circle" width="45" /></div>
                                                <div class="">
                                                    <h5 class="m-b-0 font-16 font-medium">Hanna Gover</h5><span>hgover@gmail.com</span></div>
                                            </div>
                                        </td>
                                        <td>
                                            <p class="">Elite Admin</p>
                                        </td>
                                        <td class="blue-grey-text text-darken-4 font-medium">$96K</td>
                                        <td>May 23, 2018</td>
                                        <td><span class="label label-info">Sale</span></td>
                                        <td class="green-text"><i class="fa fa-arrow-up"></i> 23%</td>
                                        <td>2356</td>
                                        <td class="blue-grey-text  text-darken-4 font-medium">$96K</td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="d-flex no-block align-items-center">
                                                <div class="m-r-10"><img src="<?php echo e(asset('/images/users/d2.jpg')); ?>" alt="user" class="circle" width="45" /></div>
                                                <div class="">
                                                    <h5 class="m-b-0 font-16 font-medium">Daniel Kristeen</h5><span>Kristeen@gmail.com</span></div>
                                            </div>
                                        </td>
                                        <td>
                                            <p class="">Real Homes WP Theme</p>
                                        </td>
                                        <td class="blue-grey-text text-darken-4 font-medium">$85K</td>
                                        <td>May 23, 2018</td>
                                        <td><span class="label cyan">Extended</span></td>
                                        <td class="green-text"><i class="fa fa-arrow-up"></i> 12%</td>
                                        <td>2198</td>
                                        <td class="blue-grey-text  text-darken-4 font-medium">$85K</td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="d-flex no-block align-items-center">
                                                <div class="m-r-10"><img src="<?php echo e(asset('/images/users/d3.jpg')); ?>" alt="user" class="circle" width="45" /></div>
                                                <div class="">
                                                    <h5 class="m-b-0 font-16 font-medium">Julian Josephs</h5><span>Josephs@gmail.com</span></div>
                                            </div>
                                        </td>
                                        <td>
                                            <p class="">MedicalPro WP Theme</p>
                                        </td>
                                        <td class="blue-grey-text text-darken-4 font-medium">$81K</td>
                                        <td>May 23, 2018</td>
                                        <td><span class="label label-primary">Multiple</span></td>
                                        <td class="orange-text"><i class="fa fa-arrow-down"></i> 07%</td>
                                        <td>1237</td>
                                        <td class="blue-grey-text  text-darken-4 font-medium">$76K</td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <div class="d-flex no-block align-items-center">
                                                <div class="m-r-10"><img src="<?php echo e(asset('/images/users/2.jpg')); ?>" alt="user" class="circle" width="45" /></div>
                                                <div class="">
                                                    <h5 class="m-b-0 font-16 font-medium">Jan Petrovic</h5><span>hgover@gmail.com</span></div>
                                            </div>
                                        </td>
                                        <td>
                                            <p class="">HostinPress Html</p>
                                        </td>
                                        <td class="blue-grey-text text-darken-4 font-medium">-$30K</td>
                                        <td>May 23, 2018</td>
                                        <td><span class="label label-warning">Tax</span></td>
                                        <td class="green-text"><i class="fa fa-arrow-up"></i> 25%</td>
                                        <td>1956</td>
                                        <td class="blue-grey-text  text-darken-4 font-medium">$90K</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <a href="javascript: void(0)"><i class="fas fa-angle-right"></i> View Complete Report</a>
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- Recent comment and chats -->
        <!-- ============================================================== -->
        <div class="row">
            <!-- Recent comment -->
            <div class="col s12 m12 l6">
                <div class="card">
                    <div class="card-content">
                        <h5 class="card-title">Recent Comments</h5>
                        <div class="comment-widgets scrollable" style="height:560px;">
                            <!-- Comment Row -->
                            <div class="d-flex flex-row comment-row">
                                <div class="p-2"><img src="<?php echo e(asset('/images/users/1.jpg')); ?>" alt="user" width="50" class="circle"></div>
                                <div class="comment-text w-100">
                                    <h6 class="font-medium">James Anderson</h6>
                                    <span class="m-b-15 db">Lorem Ipsum is simply dummy text of the printing and type setting industry. </span>
                                    <div class="comment-footer">
                                        <span class="text-muted right">April 14, 2016</span> <span class="label label-info">Pending</span> <span class="action-icons">
                                            <a href="javascript:void(0)"><i class="ti-pencil-alt"></i></a>
                                            <a href="javascript:void(0)"><i class="ti-check"></i></a>
                                            <a href="javascript:void(0)"><i class="ti-heart"></i></a>    
                                        </span> </div>
                                </div>
                            </div>
                            <!-- Comment Row -->
                            <div class="d-flex flex-row comment-row">
                                <div class="p-2"><img src="<?php echo e(asset('/images/users/4.jpg')); ?>" alt="user" width="50" class="circle"></div>
                                <div class="comment-text active w-100">
                                    <h6 class="font-medium">Michael Jorden</h6>
                                    <span class="m-b-15 db">Lorem Ipsum is simply dummy text of the printing and type setting industry. </span>
                                    <div class="comment-footer ">
                                        <span class="text-muted right">April 14, 2016</span>
                                        <span class="label label-success">Approved</span>
                                        <span class="action-icons active">
                                            <a href="javascript:void(0)"><i class="ti-pencil-alt"></i></a>
                                            <a href="javascript:void(0)"><i class="icon-close"></i></a>
                                            <a href="javascript:void(0)"><i class="ti-heart text-danger"></i></a>    
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <!-- Comment Row -->
                            <div class="d-flex flex-row comment-row">
                                <div class="p-2"><img src="<?php echo e(asset('/images/users/5.jpg')); ?>" alt="user" width="50" class="circle"></div>
                                <div class="comment-text w-100">
                                    <h6 class="font-medium">Johnathan Doeting</h6>
                                    <span class="m-b-15 db">Lorem Ipsum is simply dummy text of the printing and type setting industry. </span>
                                    <div class="comment-footer">
                                        <span class="text-muted right">April 14, 2016</span>
                                        <span class="label label-warning">Rejected</span>
                                        <span class="action-icons">
                                            <a href="javascript:void(0)"><i class="ti-pencil-alt"></i></a>
                                            <a href="javascript:void(0)"><i class="ti-check"></i></a>
                                            <a href="javascript:void(0)"><i class="ti-heart"></i></a>    
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <!-- Comment Row -->
                            <div class="d-flex flex-row comment-row">
                                <div class="p-2"><img src="<?php echo e(asset('/images/users/1.jpg')); ?>" alt="user" width="50" class="circle"></div>
                                <div class="comment-text w-100">
                                    <h6 class="font-medium">James Anderson</h6>
                                    <span class="m-b-15 db">Lorem Ipsum is simply dummy text of the printing and type setting industry. </span>
                                    <div class="comment-footer">
                                        <span class="text-muted right">April 14, 2016</span> <span class="label label-info">Pending</span> <span class="action-icons">
                                            <a href="javascript:void(0)"><i class="ti-pencil-alt"></i></a>
                                            <a href="javascript:void(0)"><i class="ti-check"></i></a>
                                            <a href="javascript:void(0)"><i class="ti-heart"></i></a>    
                                        </span> </div>
                                </div>
                            </div>
                            <!-- Comment Row -->
                            <!-- Comment Row -->
                            <div class="d-flex flex-row comment-row">
                                <div class="p-2"><img src="<?php echo e(asset('/images/users/4.jpg')); ?>" alt="user" width="50" class="circle"></div>
                                <div class="comment-text active w-100">
                                    <h6 class="font-medium">Michael Jorden</h6>
                                    <span class="m-b-15 db">Lorem Ipsum is simply dummy text of the printing and type setting industry. </span>
                                    <div class="comment-footer ">
                                        <span class="text-muted right">April 14, 2016</span>
                                        <span class="label label-success">Approved</span>
                                        <span class="action-icons active">
                                            <a href="javascript:void(0)"><i class="ti-pencil-alt"></i></a>
                                            <a href="javascript:void(0)"><i class="icon-close"></i></a>
                                            <a href="javascript:void(0)"><i class="ti-heart text-danger"></i></a>    
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <!-- Comment Row -->
                        </div>
                    </div>
                </div>
            </div>
            <!-- Recent chats -->
            <div class="col s12 m12 l6">
                <div class="card">
                    <div class="card-content">
                        <h5 class="card-title">Recent Chats</h5>
                        <div class="chat-box scrollable" style="height:480px;">
                            <!--chat Row -->
                            <ul class="chat-list">
                                <!--chat Row -->
                                <li>
                                    <div class="chat-img"><img src="<?php echo e(asset('/images/users/1.jpg')); ?>" alt="user"></div>
                                    <div class="chat-content">
                                        <h6 class="font-medium">James Anderson</h6>
                                        <div class="box bg-light-info">Lorem Ipsum is simply dummy text of the printing &amp; type setting industry.</div>
                                    </div>
                                    <div class="chat-time">10:56 am</div>
                                </li>
                                <!--chat Row -->
                                <li>
                                    <div class="chat-img"><img src="<?php echo e(asset('/images/users/2.jpg')); ?>" alt="user"></div>
                                    <div class="chat-content">
                                        <h6 class="font-medium">Bianca Doe</h6>
                                        <div class="box bg-light-info">It’s Great opportunity to work.</div>
                                    </div>
                                    <div class="chat-time">10:57 am</div>
                                </li>
                                <!--chat Row -->
                                <li class="odd">
                                    <div class="chat-content">
                                        <div class="box bg-light-inverse">I would love to join the team.</div>
                                        <br>
                                    </div>
                                </li>
                                <!--chat Row -->
                                <li class="odd">
                                    <div class="chat-content">
                                        <div class="box bg-light-inverse">Whats budget of the new project.</div>
                                        <br>
                                    </div>
                                    <div class="chat-time">10:59 am</div>
                                </li>
                                <!--chat Row -->
                                <li>
                                    <div class="chat-img"><img src="<?php echo e(asset('/images/users/3.jpg')); ?>" alt="user"></div>
                                    <div class="chat-content">
                                        <h6 class="font-medium">Angelina Rhodes</h6>
                                        <div class="box bg-light-info">Well we have good budget for the project</div>
                                    </div>
                                    <div class="chat-time">11:00 am</div>
                                </li>
                                <!--chat Row -->
                            </ul>
                        </div>
                    </div>
                    <div class="card-action">
                        <div class="row">
                            <div class="col s8">
                                <div class="input-field m-t-0 m-b-0">
                                    <textarea id="textarea1" class="materialize-textarea b-0"></textarea>
                                </div>
                            </div>
                            <div class="col s4">
                                <a class="btn-floating btn-large cyan pulse right"><i class="fas fa-paper-plane"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('/libs/chartist/dist/chartist.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/libs/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/extra-libs/sparkline/sparkline.js')); ?>"></script>
    <script src="<?php echo e(asset('/dist/js/pages/dashboards/dashboard1.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\Laravel\siakad_fira\resources\views/index.blade.php ENDPATH**/ ?>