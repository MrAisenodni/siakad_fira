

<?php $__env->startSection('title', $menu->title); ?>

<?php $__env->startSection('styles'); ?>
    
    <link href="<?php echo e(asset('/dist/css/pages/data-table.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col s12">
                <div class="card">
                    <div class="card-content">
                        <div class="row" style="margin-bottom: 5px">
                            <div class="col s8">
                                <h5 class="card-title"><?php echo e($menu->title); ?> Siswa</h5>
                            </div>
                            <div class="col s4 right-align">
                                
                            </div>
                            <?php if(session('status')): ?>
                                <div class="col s12">
                                    <div class="success-alert-bar p-15 m-t-10 green white-text" style="display: block">
                                        <?php echo e(session('status')); ?>

                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="row">
                            <div class="col s12">
                                <table id="zero_config" class="responsive-table display" style="width:100%" onload="message()">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Kelas</th>
                                            <th>Tahun Pelajaran</th>
                                            <th>Jumlah Siswa</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if($classes): ?>
                                            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clazz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr id="show" data-id="<?php echo e($clazz->id); ?>">
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($clazz->class->name); ?></td>
                                                    <td><?php echo e($clazz->study_year->name); ?></td>
                                                    <td><?php echo e($clazz->student); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
    <script src="<?php echo e(asset('/extra-libs/datatables/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/dist/js/pages/datatable/datatable-basic.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\Laravel\siakad_fira\resources\views/teachers/present/index.blade.php ENDPATH**/ ?>