<aside class="left-sidebar">
    <ul id="slide-out" class="sidenav">
        
        <li>
            <ul class="collapsible">
                <li class="small-cap"><span class="hide-menu">SEKOLAH</span></li>
                <?php if($menus): ?>
                    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($menu->parent == 0): ?>
                            <li>
                                <a href="<?php echo e($menu->url); ?>" class="collapsible-header"><i class="material-icons"><?php echo e($menu->icon); ?></i><span class="hide-menu"> <?php echo e($menu->title); ?></span></a>
                            </li>
                        <?php else: ?>
                            <li>
                                <a href="javascript: void(0);" class="collapsible-header has-arrow"><i class="material-icons"><?php echo e($menu->icon); ?></i><span class="hide-menu"> <?php echo e($menu->title); ?> </span></a>
                                <div class="collapsible-body">
                                    <ul>
                                        <?php if($menu->sub_menus): ?>
                                            <?php $__currentLoopData = $menu->sub_menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><a href="<?php echo e($sub_menu->url); ?>"><i class="material-icons"><?php echo e($sub_menu->icon); ?></i><span class="hide-menu"><?php echo e($sub_menu->title); ?></span></a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ul>
        </li>
    </ul>
</aside><?php /**PATH D:\Workspace\Laravel\siakad_fira\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>