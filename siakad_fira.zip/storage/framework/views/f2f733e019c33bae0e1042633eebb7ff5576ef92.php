

<?php $__env->startSection('title', $menu->title); ?>

<?php $__env->startSection('styles'); ?>
    
    <link href="<?php echo e(asset('/dist/css/pages/data-table.css')); ?>" rel="stylesheet">

    
    <link href="<?php echo e(asset('/libs/sweetalert2/dist/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col s12">
                <div class="card">
                    <div class="card-content">
                        <div class="row">
                            <div class="col s12">
                                <?php if($gclass): ?>
                                <div class="row">
                                    <div class="col s6"><h5 class="card-title">Wali <?php echo e($menu->title); ?> [<?php echo e($gclass->class->name); ?>]</h5></div>
                                    <div class="col s6 right-align"><h5 class="card-title">Tahun Pelajaran <?php echo e($gclass->study_year->name); ?></h5></div>
                                </div>
                                <div class="row">
                                    <div class="col s12"><h5 class="card-title">[<?php echo e($gclass->teacher->nip); ?>] <?php echo e($gclass->teacher->full_name); ?></h5></div>
                                </div>
                                <?php else: ?>
                                    <h5 class="card-title red-text">Anda bukan Wali Kelas</h5>
                                <?php endif; ?>
                            </div>
                        </div>
                        <table id="zero_config" class="responsive-table display" style="width:100%" onload="message()">
                            <thead>
                                <tr>
                                    <th>Nama Siswa</th>
                                    <th>Jenis Kelamin</th>
                                    <th>Agama</th>
                                    <th>Nomor HP/Telepon</th>
                                    <th>Alamat</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($classes): ?>
                                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="data" data-id="<?php echo e($clas->student_id); ?>">
                                            <td>[<?php echo e($clas->student->nis); ?>] <?php echo e($clas->student->full_name); ?></td>
                                            <td>
                                                <?php if($clas->student->gender == 'l'): ?>
                                                    Laki-Laki
                                                <?php else: ?>
                                                    Perempuan
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($clas->student->religion->name); ?></td>
                                            <td><?php echo e($clas->student->phone_number); ?> <?php if($clas->student->home_number): ?> /<?php echo e($clas->student->home_number); ?> <?php endif; ?></td>
                                            <td><?php echo e($clas->student->address); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
    <script src="<?php echo e(asset('/extra-libs/Datatables/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/dist/js/pages/datatable/datatable-basic.init.js')); ?>"></script>

    
    <script src="<?php echo e(asset('/libs/sweetalert2/dist/sweetalert2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/libs/sweetalert2/sweet-alert.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\Laravel\siakad_fira\resources\views/teachers/class/index.blade.php ENDPATH**/ ?>