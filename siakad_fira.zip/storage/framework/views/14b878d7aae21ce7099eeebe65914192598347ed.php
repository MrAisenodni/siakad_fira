

<?php $__env->startSection('title', $menu->title); ?>

<?php $__env->startSection('styles'); ?>
    
    <link href="<?php echo e(asset('/dist/css/pages/data-table.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col s12">
                <div class="card">
                    <div class="card-content">
                        <div class="row">
                            <div class="col s10">
                                <h5 class="card-title"><?php echo e($menu->title); ?></h5>
                            </div>
                            <?php if(session('status')): ?>
                                <div class="col s12">
                                    <div class="success-alert-bar p-15 m-t-10 green white-text" style="display: block">
                                        <?php echo e(session('status')); ?>

                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <table id="zero_config" class="responsive-table display" style="width:100%" onload="message()">
                            <thead>
                                <tr>
                                    <th>Jadwal</th>
                                    <th>Waktu</th>
                                    <th>Mata Pelajaran</th>
                                    <th>Kelas</th>
                                    <th>Guru</th>
                                    <th>Pengawas</th>
                                    <th>Tipe</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($schedules): ?>
                                    <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr id="show" data-id="<?php echo e($schedule->id); ?>">
                                            <td>
                                                <?php if($schedule->day == '1'): ?> Senin <?php endif; ?>
                                                <?php if($schedule->day == '2'): ?> Selasa <?php endif; ?>
                                                <?php if($schedule->day == '3'): ?> Rabu <?php endif; ?>
                                                <?php if($schedule->day == '4'): ?> Kamis <?php endif; ?>
                                                <?php if($schedule->day == '5'): ?> Jumat <?php endif; ?>
                                                <?php if($schedule->day == '6'): ?> Sabtu <?php endif; ?>
                                                <?php if($schedule->day == '7'): ?> Minggu <?php endif; ?>
                                            </td>
                                            <td>(<?php echo e(date('H:i', strtotime($schedule->clock_in))); ?> - <?php echo e(date('H:i', strtotime($schedule->clock_out))); ?>)</td>
                                            <td><?php echo e($schedule->lesson->lesson->name); ?></td>
                                            <td><?php echo e($schedule->lesson->class->name); ?></td>
                                            <td><?php echo e($schedule->lesson->teacher->full_name); ?></td>
                                            <td><?php if($schedule->spv_teacher_id): ?> <?php echo e($schedule->teacher->full_name); ?> <?php else: ?> - <?php endif; ?></td>
                                            <td>
                                                <?php if($schedule->type == 'uas'): ?>
                                                    <p class="red-text">UAS</p>
                                                <?php elseif($schedule->type == 'uts'): ?>
                                                    <p class="green-text">UTS</p>
                                                <?php else: ?>
                                                    Pelajaran
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
    <script src="<?php echo e(asset('/extra-libs/datatables/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/dist/js/pages/datatable/datatable-basic.init.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\Laravel\siakad_fira\resources\views/teachers/schedule/index.blade.php ENDPATH**/ ?>