

<?php $__env->startSection('title', $menu->title); ?>

<?php $__env->startSection('styles'); ?>
    
    <link href="<?php echo e(asset('/extra-libs/prism/prism.css')); ?>" rel="stylesheet">
    
    
    <link href="<?php echo e(asset('/libs/select2/dist/css/select2.css')); ?>" rel="stylesheet">
    
    
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/libs/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col s12">
                <div class="card">
                    <div class="card-content">
                        <h5 class="card-title"><?php echo e($menu->title); ?> <?php if($teacher->role == 'teacher'): ?> Guru <?php else: ?> Kepala Sekolah <?php endif; ?></h5>
                        <?php if(session('status')): ?>
                            <div class="success-alert-bar p-15 m-t-10 m-b-10 green white-text" style="display: block">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <form method="POST" action="<?php echo e(str_replace("/create", "", $menu->url)); ?>">
                            <?php echo csrf_field(); ?>
                            
                            <div class="row">
                                <div class="input-field col s3">
                                    <input id="nip" type="text" placeholder="NIP" name="nip" value="<?php echo e(old('nip', $teacher->nip)); ?>" disabled>
                                    <label for="nip">NIP <span class="materialize-red-text">*</span></label>
                                    <?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-field col s5">
                                    <input id="full_name" type="text" placeholder="Nama Lengkap" name="full_name" value="<?php echo e(old('full_name', $teacher->full_name)); ?>" disabled>
                                    <label for="full_name">Nama Lengkap <span class="materialize-red-text">*</span></label>
                                    <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-field col s4">
                                    <select id="gender" name="gender">
                                        <option <?php if(old('gender', $teacher->gender) == 'l'): ?> selected <?php endif; ?> value="l">Laki-Laki</option>
                                        <option <?php if(old('gender', $teacher->gender) == 'p'): ?> selected <?php endif; ?> value="p">Perempuan</option>
                                    </select>
                                    <label for="gender">Jenis Kelamin <span class="materialize-red-text">*</span></label>
                                    <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row">
                                <div class="input-field col s3">
                                    <input id="birth_date" class="datepicker" type="text" placeholder="dd/mm/yyyy" name="birth_date" value="<?php echo e(old('birth_date', date('d/m/Y', strtotime($teacher->birth_date)))); ?>">
                                    <label for="birth_date">Tanggal Lahir <span class="materialize-red-text">*</span></label>
                                    <?php $__errorArgs = ['birth_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-field col s5">
                                    <input id="birth_place" type="text" placeholder="Tempat Lahir" name="birth_place" value="<?php echo e(old('birth_place', $teacher->birth_place)); ?>" disabled>
                                    <label for="birth_place">Tempat Lahir <span class="materialize-red-text">*</span></label>
                                    <?php $__errorArgs = ['birth_place'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-field col s4">
                                    <select id="religion" name="religion" class="">
                                        <option value="" selected>--- SILAHKAN PILIH ---</option>
                                        <?php if($religions): ?>
                                            <?php $__currentLoopData = $religions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $religion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php if(old('religion', $teacher->religion_id) == $religion->id): ?> selected <?php endif; ?> value="<?php echo e($religion->id); ?>"><?php echo e($religion->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                    <label for="religion">Agama <span class="materialize-red-text">*</span></label>
                                    <?php $__errorArgs = ['religion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row">
                                <div class="input-field col s3">
                                    <input id="phone_number" type="text" placeholder="6285889784451" name="phone_number" value="<?php echo e(old('phone_number', $teacher->phone_number)); ?>" disabled>
                                    <label for="phone_number">No HP <span class="materialize-red-text">*</span></label>
                                    <?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-field col s5">
                                    <input id="email" type="email" placeholder="testing@test.com" name="email" value="<?php echo e(old('email', $teacher->email)); ?>" disabled>
                                    <label for="email">Email <span class="materialize-red-text">*</span></label>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-field col s4">
                                    <input id="last_study" type="text" placeholder="S1 Ilmu Komunikasi" name="last_study" value="<?php echo e(old('last_study', $teacher->last_study)); ?>" disabled>
                                    <label for="last_study">Pendidikan Terakhir <span class="materialize-red-text">*</span></label>
                                    <?php $__errorArgs = ['last_study'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <hr>
                            <div class="row">
                                <div class="col s12" style="text-align: right">
                                    <a class="waves-effect waves-light btn btn-round blue strong" href="<?php echo e($menu->url); ?>">KEMBALI</a>
                                    <button id="btn_edit" class="waves-effect waves-light btn btn-round warning strong" type="button">UBAH</button>
                                    <button id="btn_cancel" class="waves-effect waves-light btn btn-round red strong" type="button" style="display: none">BATAL</button>
                                    <button id="btn_save" class="waves-effect waves-light btn btn-round green strong" type="submit" style="display: none">SIMPAN</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
    <script src="<?php echo e(asset('/extra-libs/prism/prism.js')); ?>"></script>
    
    
    <script src="<?php echo e(asset('/libs/select2/dist/js/select2.min.js')); ?>"></script>
    
    
    <script src="<?php echo e(asset('/libs/moment/moment.js')); ?>"></script>
    <script src="<?php echo e(asset('/libs/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker-custom.js')); ?>"></script>
    
    
    <script src="<?php echo e(asset('/dist/js/form.js')); ?>"></script>
    <?php echo $__env->make('scripts.datepicker', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('scripts.select2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\Laravel\siakad_fira\resources\views/teachers/profile/index.blade.php ENDPATH**/ ?>