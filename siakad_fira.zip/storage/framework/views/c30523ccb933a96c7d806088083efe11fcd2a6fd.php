

<?php $__env->startSection('title', $menu->title); ?>

<?php $__env->startSection('styles'); ?>
    
    <link href="<?php echo e(asset('/extra-libs/prism/prism.css')); ?>" rel="stylesheet">
    
    
    <link href="<?php echo e(asset('/libs/select2/dist/css/select2.css')); ?>" rel="stylesheet">

    
    <link href="<?php echo e(asset('/dist/css/pages/data-table.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col s8">
                <div class="card">
                    <div class="card-content">
                        <div class="row">
                            <div class="col s6">
                                <h5 class="card-title">History <?php echo e($menu->title); ?></h5>
                            </div>
                            <div class="col s6 right-align">
                                <a class="waves-effect waves-light btn btn-round green strong btn modal-trigger" href="#create">TAMBAH</a>
                                
                            </div>
                        </div>
                        <div class="row">
                            <?php if(session('status')): ?>
                                <div class="col s12">
                                    <div class="success-alert-bar p-15 m-t-10 green white-text" style="display: block">
                                        <?php echo e(session('status')); ?>

                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php if(session('error')): ?>
                                <div class="col s12">
                                    <div class="success-alert-bar p-15 m-t-10 red white-text" style="display: block">
                                        <?php echo e(session('error')); ?>

                                    </div>
                                </div>
                            <?php endif; ?>
                            <div class="col s12">
                                <table id="zero_config" class="responsive-table display" style="width:100%" onload="message()">
                                    <thead>
                                        <tr>
                                            <th>Tahun</th>
                                            <th>Bulan</th>
                                            <th>Nominal</th>
                                            <th>Status</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if($paystuds): ?>
                                            <?php $__currentLoopData = $paystuds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr id="data" data-url="<?php echo e($menu->url); ?>/<?php echo e($pay->id); ?>/edit" data-id="<?php echo e($pay->id); ?>" <?php if($payment->id == $pay->id): ?> class="blue white-text" <?php endif; ?>>
                                                    <td><?php echo e($pay->year); ?></td>
                                                    <td>
                                                        <?php if($months): ?>
                                                            <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($pay->month == $month->id): ?>
                                                                    <?php echo e($month->name); ?>

                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?php echo e('Rp '.number_format($pay->amount, 0, ',', '.')); ?></td>
                                                    <td>
                                                        <?php if($pay->status == 'lunas'): ?>
                                                            <button class="waves-effect waves-light btn btn-round green strong" type="button">LUNAS</button>
                                                        <?php else: ?>
                                                            <button class="waves-effect waves-light btn btn-round red strong" type="button">BELUM LUNAS</button>
                                                        <?php endif; ?>    
                                                    </td>
                                                    <td id="no-data" class="text-center" style="width: 5%">
                                                        <form action="<?php echo e($menu->url); ?>/<?php echo e($pay->id); ?>" method="POST" class="d-inline">
                                                            <?php echo method_field('delete'); ?>
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="student" value="<?php echo e($pay->student_id); ?>">
                                                            <button type="submit" class="transparent fas fa-trash <?php if($payment->id == $pay->id): ?> white-text <?php else: ?> materialize-red-text <?php endif; ?>" style="border: 0px"></button>
                                                        </form>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col s4">
                <div class="card">
                    <div class="card-content">
                        <h5 class="card-title">Ubah <?php echo e($menu->title); ?></h5>
                        <form method="POST" action="<?php echo e(str_replace("/edit", "", url()->current())); ?>">
                            <?php echo method_field('put'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <input type="hidden" name="student" value="<?php echo e($payment->student_id); ?>">
                                <div class="input-field col s12">
                                    <input id="clas" type="text" placeholder="10" name="clas" value="<?php echo e(old('clas', $payment->student->class->class->name)); ?>" readonly>
                                    <label for="clas">Kelas</label>
                                    <?php $__errorArgs = ['clas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s12">
                                    <select id="payment" name="payment" class="auto_fill">
                                        <option value="" selected>--- SILAHKAN PILIH ---</option>
                                        <?php if($payments): ?>
                                            <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php if(old('payment', $payment->payment_id) == $pay->id): ?> selected <?php endif; ?> value="<?php echo e($pay->id); ?>"><?php echo e($pay->year); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                    <label for="payment">Tahun</label>
                                    <?php $__errorArgs = ['payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-field col s12">
                                    <select id="month" name="month">
                                        <?php if($months): ?>
                                            <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option <?php if(old('month', $payment->month) == $month->id): ?> selected <?php endif; ?> value="<?php echo e($month->id); ?>"><?php echo e($month->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                    <label for="month">Bulan</label>
                                    <?php $__errorArgs = ['month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="input-field col s12">
                                    <input id="year" type="hidden" name="year" value="<?php echo e(old('year', $payment->payment->year)); ?>" readonly>
                                    <input id="amount" type="text" name="amount" value="<?php echo e(old('amount', 'Rp '.number_format($payment->payment->amount, 0, ',', '.'))); ?>" readonly>
                                    <label for="amount">Nominal</label>
                                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <hr>
                            <div class="row">
                                <div class="col s12" style="text-align: right">
                                    <a class="waves-effect waves-light btn btn-round blue strong" href="<?php echo e($menu->url); ?>">KEMBALI</a>
                                    <button class="waves-effect waves-light btn btn-round green strong" type="submit">BAYAR</button>
                                </div>
                            </div>
                        </form>
                        
                        
                    </div>
                </div>
            </div>
            <div id="create" class="modal">
                <div class="card">
                    <div class="card-content">
                        <div class="row">
                            <div class="col s12">
                                <h5 class="card-title">Tambah <?php echo e($menu->title); ?></h5>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col s12">
                                <form method="POST" action="<?php echo e(str_replace("/create", "", $menu->url)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <input type="hidden" name="uid" id="url_id" value="<?php echo e($payment->id); ?>">
                                        <input type="hidden" name="mod_student" id="mod_student" value="<?php echo e($payment->student_id); ?>">
                                        <div class="input-field col s12">
                                            <select id="mod_payment" name="mod_payment" class="modal_auto_fill">
                                                <option value="" selected>--- SILAHKAN PILIH ---</option>
                                                <?php if($payments): ?>
                                                    <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php if(old('mod_payment') == $payment->id): ?> selected <?php endif; ?> value="<?php echo e($payment->id); ?>"><?php echo e($payment->year); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                            <label for="mod_payment">Tahun</label>
                                            <?php $__errorArgs = ['mod_payment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="error"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="input-field col s12">
                                            <select id="mod_month" name="mod_month">
                                                <?php if($months): ?>
                                                    <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option <?php if(old('mod_month') == $month->id): ?> selected <?php endif; ?> value="<?php echo e($month->id); ?>"><?php echo e($month->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                            </select>
                                            <label for="mod_month">Bulan</label>
                                            <?php $__errorArgs = ['mod_month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="error"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="input-field col s12">
                                            <input id="mod_year" type="hidden" name="mod_year" value="<?php echo e(old('mod_year')); ?>" readonly>
                                            <input id="mod_amount" type="text" placeholder="Rp 2.000.000" name="mod_amount" value="<?php echo e(old('mod_amount')); ?>" readonly>
                                            <label for="mod_amount">Nominal</label>
                                            <?php $__errorArgs = ['mod_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="error"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                        
                                    <hr>
                                    <div class="row">
                                        <div class="col s12" style="text-align: right">
                                            <a href="#!" class="modal-action modal-close btn btn-round blue strong">TUTUP</a>
                                            
                                            <button class="waves-effect waves-light btn btn-round green strong" type="submit">BAYAR</button>
                                        </div>
                                    </div>
                                </form>                        
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    
    <script src="<?php echo e(asset('/extra-libs/prism/prism.js')); ?>"></script>

    
    <script src="<?php echo e(asset('/libs/select2/dist/js/select2.min.js')); ?>"></script>

    
    <script src="<?php echo e(asset('/extra-libs/Datatables/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/dist/js/pages/datatable/datatable-basic.init.js')); ?>"></script>

    
    <script src="<?php echo e(asset('/dist/js/form.js')); ?>"></script>
    <?php echo $__env->make('scripts.select2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Workspace\Laravel\siakad_fira\resources\views/studies/payment/edit.blade.php ENDPATH**/ ?>